# Additional integration and reference-provenance evidence

This archive supports Tables S19a–b and S20a–d. WGS analyses use whole-assembly primary alignments; MAPQ 0 and 20 results are supplied separately. Fp133/CLIB189 share the assembly BioSample; Fol4287 is an independent deposit of the same named strain. Gene-edge tests and full-block linkage tests are distinct. Spanning-alignments.tsv includes CIGARs for the 112 unique high-quality Fp133 molecules.

To rerun the mapping, place the `wgs/` folder under `analysis/revision_20261104/` in the article repository. Set `GMO_CONDA_ENVS` to the directory holding the conda environments (`annot`, `minimap2_env`, `PlantCad2`) or adapt the tool paths. Obtain the three reference assemblies at the paths in `map_reads.py`; compare the SHA256 values in the run provenance files. Download checksum-verified reads with `python download_ranges.py RUN`, then run `python map_reads.py RUN`. The latter runs `summarize_reads.py`. Python needs numpy and pysam. minimap2 2.30, SAMtools 1.24 and bedtools 2.31.1 were used. Raw FASTQ and BAM files are not included; public file URLs, byte counts and MD5 values identify the inputs.

The `plasmids/` directory contains the source-to-protein mapping and the 42 stored GenBank records. All 302 original amino-acid sequences match their source CDS translations; only provenance labels were corrected. The legacy input and coordinate table are included to reproduce the audit. The corrected FASTA preserves sequence order but uses unique source/coordinate labels. Existing analyses retain their legacy identifiers, linked through Table S19b.

`MANIFEST.tsv` lists byte sizes and SHA256 values for every other file. The two new integration-filtered M0 analyses are in Data S4.
