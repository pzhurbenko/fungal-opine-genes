seqfile = cus_Bol.codon.phy
treefile = cus_Bol.tree.nwk
outfile = cus_Bol.M8a.out
noisy = 0
verbose = 0
runmode = 0
seqtype = 1
CodonFreq = 2
model = 0
NSsites = 8
icode = 0
fix_kappa = 0
kappa = 2
fix_omega = 1
omega = 1


cleandata = 0
