seqfile = acs_pKerr14a.codon.phy
treefile = acs_pKerr14a.tree.nwk
outfile = acs_pKerr14a.M8a.out
noisy = 0
verbose = 0
runmode = 0
seqtype = 1
CodonFreq = 2
model = 0
NSsites = 8
icode = 0
fix_kappa = 0
kappa = 2
fix_omega = 1
omega = 1


cleandata = 0
